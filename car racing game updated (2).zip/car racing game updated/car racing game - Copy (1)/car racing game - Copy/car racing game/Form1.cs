﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace car_racing_game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            over.Visible= false;
            tryagain_button.Visible = false;
            tryagain_button.Click += new EventHandler(this.tryagain_button_Click);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            moveline(gamespeed);
            dummy(gamespeed);
            GameOver();
            Coins(gamespeed);
            CoinIncrease();
        }
        int CollectedCoins = 0;

        //moving road
        void moveline(int speed)
        {
            if (pictureBox1.Top >= 450)
            {
                pictureBox1.Top = 0;
            }
            else { pictureBox1.Top += speed; }
            if (pictureBox2.Top >= 450)
            {
                pictureBox2.Top = 0;
            }
            else { pictureBox2.Top += speed; }
            if (pictureBox3.Top >= 450)
            {
                pictureBox3.Top = 0;
            }
            else { pictureBox3.Top += speed; }
            if (pictureBox4.Top >= 450)
            {
                pictureBox4.Top = 0;
            }
            else { pictureBox4.Top += speed; }

        }


        Random r = new Random();
        int x, y;

        //dummy cars
        void dummy(int speed)
        {
            if (dummy3.Top >= 450)
            {
                x=r.Next(230, 420);
                y = r.Next(0,0);
                dummy3.Location = new Point(x,y);
            }
            else { dummy3.Top += speed; }
            if (dummy1.Top >= 450)
            {
                x = r.Next(80, 200);
                y = r.Next(0, 0);
                dummy1.Location = new Point(x, y);
            }
            else { dummy1.Top += speed; }
            if (dummy2.Top >= 450)
            {
                x = r.Next(0, 150);
                y = r.Next(0, 0);
                dummy2.Location = new Point(x, y);
            }
            else { dummy2.Top += speed; }

        }
        //coins
        void Coins(int speed)
        {
            if (coin1.Top >= 450)
            {
                x = r.Next(230, 350);
                y = r.Next(0, 0);
                coin1.Location = new Point(x, y);
            }
            else { coin1.Top += speed; }
            if (coin2.Top >= 450)
            {
                x = r.Next(80, 200);
                y = r.Next(0, 0);
                coin2.Location = new Point(x, y);
            }
            else { coin2.Top += speed; }
            if (coin3.Top >= 450)
            {
                x = r.Next(0, 100);
                y = r.Next(0, 0);
                coin3.Location = new Point(x, y);
            }
            else { coin3.Top += speed; }
            if (coin4.Top >= 450)
            {
                x = r.Next(0, 400);
                y = r.Next(0, 0);
                coin4.Location = new Point(x, y);
            }
            else { coin4.Top += speed; }

        }
        //score increment
        void CoinIncrease()
        {
            if (car.Bounds.IntersectsWith(coin1.Bounds))
            {
                CollectedCoins++;
                collected.Text = "Coins= "+CollectedCoins.ToString();
                x = r.Next(50,300);
                coin1.Location= new Point(x,0);
            }
            if (car.Bounds.IntersectsWith(coin2.Bounds))
            {
                CollectedCoins++;
                collected.Text = "Coins= " + CollectedCoins.ToString();
                x = r.Next(50, 300);
                coin2.Location = new Point(x, 0);
            }
            if (car.Bounds.IntersectsWith(coin3.Bounds))
            {
                CollectedCoins++;
                collected.Text = "Coins= " + CollectedCoins.ToString();
                x = r.Next(50, 300);
                coin3.Location = new Point(x, 0);
            }
            if (car.Bounds.IntersectsWith(coin4.Bounds))
            {
                CollectedCoins++;
                collected.Text = "Coins= " + CollectedCoins.ToString();
                x = r.Next(50, 300);
                coin4.Location = new Point(x, 0);
            }
        }
        //game over func
        void GameOver()
        {
            if (car.Bounds.IntersectsWith(dummy1.Bounds) || car.Bounds.IntersectsWith(dummy2.Bounds) || car.Bounds.IntersectsWith(dummy3.Bounds))
            {
                timer1.Enabled = false;
                over.Visible = true;
                tryagain_button.Visible = true;
            }
        }

        //key works
        int gamespeed = 0;

        private void dummy2_Click(object sender, EventArgs e)
        {

        }

        private void ScoreCard_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tryagain_button_Click(object sender, EventArgs e)
        {
            ResetGame();
        }

        void ResetGame()
        {
            timer1.Enabled = true;
            over.Visible = false;
            tryagain_button.Visible = false;
            CollectedCoins = 0;
            collected.Text = "Coins= 0";
            gamespeed = 0;

            
            car.Location = new Point(160, 300);  

            dummy1.Location = new Point(r.Next(80, 200),100);
            dummy2.Location = new Point(r.Next(0, 150), 200);
            dummy3.Location = new Point(r.Next(230, 400), 300);

            coin1.Location = new Point(r.Next(230, 350), 0);
            coin2.Location = new Point(r.Next(80, 200), 0);
            coin3.Location = new Point(r.Next(0, 100), 0);
            coin4.Location = new Point(r.Next(0, 400), 0);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && car.Left>0)
            {
                car.Left += -(gamespeed+8);
            }
            if (e.KeyCode == Keys.Right && car.Left<380)
            {
                car.Left +=(gamespeed+8);
            }
            if (e.KeyCode == Keys.Up )
                if (gamespeed < 21)
                { gamespeed++; }

            
            if(e.KeyCode==Keys.Down)
                if(gamespeed>0)
                { gamespeed--;}
            
        }
    }
}

